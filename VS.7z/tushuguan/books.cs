﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tushuguan
{
    class books
    {
        public string 书号 { get; set; }
        public string 书名 { get; set; }
        public string 种类 { get; set; }
        public string 数量 { get; set; }
        public string 存放位置 { get; set; }
    }
}
