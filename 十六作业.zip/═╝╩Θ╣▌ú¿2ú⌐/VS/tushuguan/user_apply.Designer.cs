﻿namespace tushuguan
{
    partial class user_apply
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_apl_sno = new System.Windows.Forms.Label();
            this.lab_apl_class = new System.Windows.Forms.Label();
            this.lab_apl_sname = new System.Windows.Forms.Label();
            this.lab_apl_sex = new System.Windows.Forms.Label();
            this.lab_apl_phone = new System.Windows.Forms.Label();
            this.txb_apl_sno = new System.Windows.Forms.TextBox();
            this.txb_apl_class = new System.Windows.Forms.TextBox();
            this.txb_apl_sname = new System.Windows.Forms.TextBox();
            this.txb_apl_phone = new System.Windows.Forms.TextBox();
            this.btn_apl_ok = new System.Windows.Forms.Button();
            this.rbt_apl_woman = new System.Windows.Forms.RadioButton();
            this.rbt_apl_man = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // lab_apl_sno
            // 
            this.lab_apl_sno.AutoSize = true;
            this.lab_apl_sno.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_apl_sno.Location = new System.Drawing.Point(137, 86);
            this.lab_apl_sno.Name = "lab_apl_sno";
            this.lab_apl_sno.Size = new System.Drawing.Size(152, 28);
            this.lab_apl_sno.TabIndex = 0;
            this.lab_apl_sno.Text = "学    号：";
            // 
            // lab_apl_class
            // 
            this.lab_apl_class.AutoSize = true;
            this.lab_apl_class.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_apl_class.Location = new System.Drawing.Point(137, 150);
            this.lab_apl_class.Name = "lab_apl_class";
            this.lab_apl_class.Size = new System.Drawing.Size(152, 28);
            this.lab_apl_class.TabIndex = 1;
            this.lab_apl_class.Text = "班    级：";
            // 
            // lab_apl_sname
            // 
            this.lab_apl_sname.AutoSize = true;
            this.lab_apl_sname.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_apl_sname.Location = new System.Drawing.Point(137, 208);
            this.lab_apl_sname.Name = "lab_apl_sname";
            this.lab_apl_sname.Size = new System.Drawing.Size(152, 28);
            this.lab_apl_sname.TabIndex = 2;
            this.lab_apl_sname.Text = "姓    名：";
            // 
            // lab_apl_sex
            // 
            this.lab_apl_sex.AutoSize = true;
            this.lab_apl_sex.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_apl_sex.Location = new System.Drawing.Point(137, 285);
            this.lab_apl_sex.Name = "lab_apl_sex";
            this.lab_apl_sex.Size = new System.Drawing.Size(152, 28);
            this.lab_apl_sex.TabIndex = 3;
            this.lab_apl_sex.Text = "性    别：";
            // 
            // lab_apl_phone
            // 
            this.lab_apl_phone.AutoSize = true;
            this.lab_apl_phone.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_apl_phone.Location = new System.Drawing.Point(137, 357);
            this.lab_apl_phone.Name = "lab_apl_phone";
            this.lab_apl_phone.Size = new System.Drawing.Size(152, 28);
            this.lab_apl_phone.TabIndex = 4;
            this.lab_apl_phone.Text = "联系方式：";
            // 
            // txb_apl_sno
            // 
            this.txb_apl_sno.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_apl_sno.Location = new System.Drawing.Point(296, 81);
            this.txb_apl_sno.Name = "txb_apl_sno";
            this.txb_apl_sno.Size = new System.Drawing.Size(318, 38);
            this.txb_apl_sno.TabIndex = 5;
            // 
            // txb_apl_class
            // 
            this.txb_apl_class.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_apl_class.Location = new System.Drawing.Point(296, 145);
            this.txb_apl_class.Name = "txb_apl_class";
            this.txb_apl_class.Size = new System.Drawing.Size(318, 38);
            this.txb_apl_class.TabIndex = 6;
            // 
            // txb_apl_sname
            // 
            this.txb_apl_sname.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_apl_sname.Location = new System.Drawing.Point(296, 203);
            this.txb_apl_sname.Name = "txb_apl_sname";
            this.txb_apl_sname.Size = new System.Drawing.Size(318, 38);
            this.txb_apl_sname.TabIndex = 7;
            // 
            // txb_apl_phone
            // 
            this.txb_apl_phone.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txb_apl_phone.Location = new System.Drawing.Point(296, 352);
            this.txb_apl_phone.Name = "txb_apl_phone";
            this.txb_apl_phone.Size = new System.Drawing.Size(318, 38);
            this.txb_apl_phone.TabIndex = 9;
            // 
            // btn_apl_ok
            // 
            this.btn_apl_ok.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_apl_ok.Location = new System.Drawing.Point(639, 437);
            this.btn_apl_ok.Name = "btn_apl_ok";
            this.btn_apl_ok.Size = new System.Drawing.Size(90, 48);
            this.btn_apl_ok.TabIndex = 10;
            this.btn_apl_ok.Text = "注册";
            this.btn_apl_ok.UseVisualStyleBackColor = true;
            this.btn_apl_ok.Click += new System.EventHandler(this.btn_apl_ok_Click);
            // 
            // rbt_apl_woman
            // 
            this.rbt_apl_woman.AutoSize = true;
            this.rbt_apl_woman.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbt_apl_woman.Location = new System.Drawing.Point(335, 285);
            this.rbt_apl_woman.Name = "rbt_apl_woman";
            this.rbt_apl_woman.Size = new System.Drawing.Size(61, 32);
            this.rbt_apl_woman.TabIndex = 11;
            this.rbt_apl_woman.TabStop = true;
            this.rbt_apl_woman.Text = "女";
            this.rbt_apl_woman.UseVisualStyleBackColor = true;
            // 
            // rbt_apl_man
            // 
            this.rbt_apl_man.AutoSize = true;
            this.rbt_apl_man.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbt_apl_man.Location = new System.Drawing.Point(455, 285);
            this.rbt_apl_man.Name = "rbt_apl_man";
            this.rbt_apl_man.Size = new System.Drawing.Size(61, 32);
            this.rbt_apl_man.TabIndex = 12;
            this.rbt_apl_man.TabStop = true;
            this.rbt_apl_man.Text = "男";
            this.rbt_apl_man.UseVisualStyleBackColor = true;
            // 
            // user_apply
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 565);
            this.Controls.Add(this.rbt_apl_man);
            this.Controls.Add(this.rbt_apl_woman);
            this.Controls.Add(this.btn_apl_ok);
            this.Controls.Add(this.txb_apl_phone);
            this.Controls.Add(this.txb_apl_sname);
            this.Controls.Add(this.txb_apl_class);
            this.Controls.Add(this.txb_apl_sno);
            this.Controls.Add(this.lab_apl_phone);
            this.Controls.Add(this.lab_apl_sex);
            this.Controls.Add(this.lab_apl_sname);
            this.Controls.Add(this.lab_apl_class);
            this.Controls.Add(this.lab_apl_sno);
            this.Name = "user_apply";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "用户注册";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_apl_sno;
        private System.Windows.Forms.Label lab_apl_class;
        private System.Windows.Forms.Label lab_apl_sname;
        private System.Windows.Forms.Label lab_apl_sex;
        private System.Windows.Forms.Label lab_apl_phone;
        private System.Windows.Forms.TextBox txb_apl_sno;
        private System.Windows.Forms.TextBox txb_apl_class;
        private System.Windows.Forms.TextBox txb_apl_sname;
        private System.Windows.Forms.TextBox txb_apl_phone;
        private System.Windows.Forms.Button btn_apl_ok;
        private System.Windows.Forms.RadioButton rbt_apl_woman;
        private System.Windows.Forms.RadioButton rbt_apl_man;
    }
}