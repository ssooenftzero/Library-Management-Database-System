﻿namespace tushuguan
{
    partial class user_alter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lab_alt_sno = new System.Windows.Forms.Label();
            this.lab_alt_class = new System.Windows.Forms.Label();
            this.lab_alt_sname = new System.Windows.Forms.Label();
            this.lab_alt_sex = new System.Windows.Forms.Label();
            this.lab_alt_phone = new System.Windows.Forms.Label();
            this.txt_alt_sno = new System.Windows.Forms.TextBox();
            this.txt_alt_class = new System.Windows.Forms.TextBox();
            this.txt_alt_sname = new System.Windows.Forms.TextBox();
            this.txt_alt_phone = new System.Windows.Forms.TextBox();
            this.btn_alt_ok = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbt_alt_woman = new System.Windows.Forms.RadioButton();
            this.rbt_alt_man = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lab_alt_sno
            // 
            this.lab_alt_sno.AutoSize = true;
            this.lab_alt_sno.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_alt_sno.Location = new System.Drawing.Point(126, 75);
            this.lab_alt_sno.Name = "lab_alt_sno";
            this.lab_alt_sno.Size = new System.Drawing.Size(152, 28);
            this.lab_alt_sno.TabIndex = 0;
            this.lab_alt_sno.Text = "学    号：";
            // 
            // lab_alt_class
            // 
            this.lab_alt_class.AutoSize = true;
            this.lab_alt_class.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_alt_class.Location = new System.Drawing.Point(126, 137);
            this.lab_alt_class.Name = "lab_alt_class";
            this.lab_alt_class.Size = new System.Drawing.Size(152, 28);
            this.lab_alt_class.TabIndex = 1;
            this.lab_alt_class.Text = "班    级：";
            // 
            // lab_alt_sname
            // 
            this.lab_alt_sname.AutoSize = true;
            this.lab_alt_sname.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_alt_sname.Location = new System.Drawing.Point(126, 206);
            this.lab_alt_sname.Name = "lab_alt_sname";
            this.lab_alt_sname.Size = new System.Drawing.Size(152, 28);
            this.lab_alt_sname.TabIndex = 2;
            this.lab_alt_sname.Text = "姓    名：";
            // 
            // lab_alt_sex
            // 
            this.lab_alt_sex.AutoSize = true;
            this.lab_alt_sex.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_alt_sex.Location = new System.Drawing.Point(126, 272);
            this.lab_alt_sex.Name = "lab_alt_sex";
            this.lab_alt_sex.Size = new System.Drawing.Size(152, 28);
            this.lab_alt_sex.TabIndex = 3;
            this.lab_alt_sex.Text = "性    别：";
            // 
            // lab_alt_phone
            // 
            this.lab_alt_phone.AutoSize = true;
            this.lab_alt_phone.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lab_alt_phone.Location = new System.Drawing.Point(126, 346);
            this.lab_alt_phone.Name = "lab_alt_phone";
            this.lab_alt_phone.Size = new System.Drawing.Size(152, 28);
            this.lab_alt_phone.TabIndex = 4;
            this.lab_alt_phone.Text = "联系方式：";
            // 
            // txt_alt_sno
            // 
            this.txt_alt_sno.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_alt_sno.Location = new System.Drawing.Point(290, 75);
            this.txt_alt_sno.Name = "txt_alt_sno";
            this.txt_alt_sno.Size = new System.Drawing.Size(358, 38);
            this.txt_alt_sno.TabIndex = 5;
            // 
            // txt_alt_class
            // 
            this.txt_alt_class.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_alt_class.Location = new System.Drawing.Point(290, 137);
            this.txt_alt_class.Name = "txt_alt_class";
            this.txt_alt_class.Size = new System.Drawing.Size(358, 38);
            this.txt_alt_class.TabIndex = 6;
            // 
            // txt_alt_sname
            // 
            this.txt_alt_sname.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_alt_sname.Location = new System.Drawing.Point(290, 206);
            this.txt_alt_sname.Name = "txt_alt_sname";
            this.txt_alt_sname.Size = new System.Drawing.Size(358, 38);
            this.txt_alt_sname.TabIndex = 7;
            this.txt_alt_sname.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // txt_alt_phone
            // 
            this.txt_alt_phone.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_alt_phone.Location = new System.Drawing.Point(290, 336);
            this.txt_alt_phone.Name = "txt_alt_phone";
            this.txt_alt_phone.Size = new System.Drawing.Size(358, 38);
            this.txt_alt_phone.TabIndex = 9;
            // 
            // btn_alt_ok
            // 
            this.btn_alt_ok.Font = new System.Drawing.Font("宋体", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_alt_ok.Location = new System.Drawing.Point(595, 433);
            this.btn_alt_ok.Name = "btn_alt_ok";
            this.btn_alt_ok.Size = new System.Drawing.Size(98, 52);
            this.btn_alt_ok.TabIndex = 10;
            this.btn_alt_ok.Text = "修改";
            this.btn_alt_ok.UseVisualStyleBackColor = true;
            this.btn_alt_ok.Click += new System.EventHandler(this.btn_alt_ok_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rbt_alt_woman);
            this.panel1.Controls.Add(this.rbt_alt_man);
            this.panel1.Location = new System.Drawing.Point(290, 272);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(164, 41);
            this.panel1.TabIndex = 13;
            // 
            // rbt_alt_woman
            // 
            this.rbt_alt_woman.AutoSize = true;
            this.rbt_alt_woman.Location = new System.Drawing.Point(94, 12);
            this.rbt_alt_woman.Name = "rbt_alt_woman";
            this.rbt_alt_woman.Size = new System.Drawing.Size(43, 19);
            this.rbt_alt_woman.TabIndex = 14;
            this.rbt_alt_woman.TabStop = true;
            this.rbt_alt_woman.Text = "女";
            this.rbt_alt_woman.UseVisualStyleBackColor = true;
            // 
            // rbt_alt_man
            // 
            this.rbt_alt_man.AutoSize = true;
            this.rbt_alt_man.Location = new System.Drawing.Point(26, 12);
            this.rbt_alt_man.Name = "rbt_alt_man";
            this.rbt_alt_man.Size = new System.Drawing.Size(43, 19);
            this.rbt_alt_man.TabIndex = 13;
            this.rbt_alt_man.TabStop = true;
            this.rbt_alt_man.Text = "男";
            this.rbt_alt_man.UseVisualStyleBackColor = true;
            // 
            // user_alter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 565);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_alt_ok);
            this.Controls.Add(this.txt_alt_phone);
            this.Controls.Add(this.txt_alt_sname);
            this.Controls.Add(this.txt_alt_class);
            this.Controls.Add(this.txt_alt_sno);
            this.Controls.Add(this.lab_alt_phone);
            this.Controls.Add(this.lab_alt_sex);
            this.Controls.Add(this.lab_alt_sname);
            this.Controls.Add(this.lab_alt_class);
            this.Controls.Add(this.lab_alt_sno);
            this.Name = "user_alter";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "用户信息修改";
            this.Load += new System.EventHandler(this.user_alter_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_alt_sno;
        private System.Windows.Forms.Label lab_alt_class;
        private System.Windows.Forms.Label lab_alt_sname;
        private System.Windows.Forms.Label lab_alt_sex;
        private System.Windows.Forms.Label lab_alt_phone;
        private System.Windows.Forms.TextBox txt_alt_sno;
        private System.Windows.Forms.TextBox txt_alt_class;
        private System.Windows.Forms.TextBox txt_alt_sname;
        private System.Windows.Forms.TextBox txt_alt_phone;
        private System.Windows.Forms.Button btn_alt_ok;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbt_alt_woman;
        private System.Windows.Forms.RadioButton rbt_alt_man;
    }
}